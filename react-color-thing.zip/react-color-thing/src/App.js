import React, { Component } from 'react';
import ColorInput from './components/colorInput';
import ColorOutput from './components/colorOutput';
import MeaningOutput from './components/meaningOutput';
import store from './store.js';
import './App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
        <ColorInput clickHandler={this.getColors} data={store.getState().data} />
        <ColorOutput scheme={store.getState().hsl} data={store.getState().data} />
        <div id="vr">&nbsp;</div>
        <MeaningOutput meaning={store.getState().baseColor} />
      </div>
    );
  }
}

export default App;
