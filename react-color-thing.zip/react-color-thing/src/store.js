import { createStore } from 'redux';

const reducer = function(state, action) {
    console.log(state);
    console.log(action.type);

    switch(action.type) {
        case "CHANGE_INPUT_COLOR":
            return Object.assign({}, state, { newColor:action.newColor })
        case "CHANGE_MODE":
            return Object.assign({}, state, { mode:action.newMode })
        case "CHANGE_BASE_COLOR":
            return Object.assign({}, state, { newBaseColor:action.newBaseColor })
        case "CHANGE_SCHEME_DATA":
            return Object.assign({}, state, { schemeData:action.schemeData })
        case "CHANGE_MEANING":
            return Object.assign({}, state, { meaning:action.meaning })
        //default: console.log("invalid action.type value");
    }
    console.log(state);
    return state;
}

const store = createStore(reducer, {newColor:"", mode:"unset", newBaseColor:"", schemeData:{}, meaning:""});

store.subscribe(() => {
    //console.log("store changed. new store:", store.getState());
    //
})

export default store