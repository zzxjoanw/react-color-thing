import React, { Component } from 'react';
import store from '../store.js';

export default class ColorInput extends Component {

    getColors = () => {
        store.dispatch({ type: "CHANGE_INPUT_COLOR", newColor: document.getElementsByName("color")[0].value });
        store.dispatch({ type: "CHANGE_MODE", newMode: document.getElementsByName("mode")[0].value });
        let url = 'https://www.thecolorapi.com/scheme?format=json&hex='+store.getState().newColor+'&mode='+store.getState().mode;
        //console.log(url);
        fetch(url)
            .then(response => response.json())
            .then(data => {
                store.dispatch({ type: "CHANGE_SCHEME_DATA", schemeData: data })
            })
            .catch(error => {
                console.log(error);
            });
    }

    render() {
        return (
            <header>
                <input type="text" name="color" defaultValue={store.getState().newColor} />
                <select name="mode">
                    <option>Choose a color scheme type</option>
                    <option value="monochrome">Monochrome</option>
                    <option value="analogic">Analogic</option>
                    <option value="complement">Complement</option>
                </select>
                <div className="buttonWrap">
                    <button onClick={this.getColors}>Bring me that rainbow</button>
                </div>
            </header>
        );
    }
}