import React, { Component } from 'react';
import store from '../store.js';

export default class ColorOutput extends Component {
    componentDidUpdate() {
        return (
            <div id="colorOutput">new: {store.getState().schemeData.colors}</div>
        );
    }

    render() {
        //console.log(store);
        return (
            <div id="colorOutput">{store.getState().mode}</div>
        );
    }
}