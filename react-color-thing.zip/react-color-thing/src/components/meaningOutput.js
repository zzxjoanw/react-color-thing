import React, { Component } from 'react';
import store from '../store.js';

export default class MeaningOutput extends Component {
    render() {
        return (
            <div id="meaningOutput">{store.getState().meaning}</div>
        );
    }
}